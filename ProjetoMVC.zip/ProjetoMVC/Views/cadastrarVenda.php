<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastrar vendas</title>
    <style>
        body {
            background-color: #383838;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        h1 {
        color: #ffffff;
        text-align: center;
        margin-top: 50px;
    }

    h3 {
        color: #ffffff;
    }

    form {
        margin-top: 30px;
        text-align: center;
    }

    input[type="text"],
    input[type="number"],
    input[type="email"],
    input[type="submit"] {
        padding: 10px;
        margin-bottom: 10px;
        width: 300px;
        border-radius: 4px;
        border: none;
    }

    input[type="submit"] {
        background-color: #442264;
        color: white;
        cursor: pointer;
    }

    input[type="submit"]:hover {
        background-color: #4776bd;
    }

    a {
        display: block;
        text-align: center;
        margin-top: 20px;
        text-decoration: none;
        color: #ffffff;
    }

    button {
        background-color: #442264;
        border: none;
        color: white;
        padding: 10px 20px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 16px;
        margin: 4px 2px;
        cursor: pointer;
        border-radius: 4px;
    }

    button:hover {
        background-color: #4776bd;
    }
</style>

</head>
<body>
    
<center>
    
    <h1>_________Cadastrar vendas_________ </h1>
    <form action="" method="post">
        
        <h3>Funcionário:</h3>
        <select name="id_funcionario" id="id_funcionario">
            <?php
            include '../Models/crud.php';
            $crud = new Crud();
            $funcionarios = $crud->getData("SELECT id, nome_fun FROM funcionarios");
            foreach ($funcionarios as $funcionario) {
                $id = $funcionario['id'];
                $nome = $funcionario['nome_fun'];
                echo "<option value='$id'>$nome</option>";
            }
            ?>
        </select>

        <h3>Produto:</h3>
        <select name="id_produto" id="id_produto">
            <?php
            $produtos = $crud->getData("SELECT id, nome_prod FROM produtos");
            foreach ($produtos as $produto) {
                $id = $produto['id'];
                $nome = $produto['nome_prod'];
                echo "<option value='$id'>$nome</option>";
            }
            ?>
        </select>

        <h3>Cliente:</h3>
        <select name="id_cliente" id="id_cliente">
            <?php
            $clientes = $crud->getData("SELECT id, nome_cli FROM clientes");
            foreach ($clientes as $cliente) {
                $id = $cliente['id'];
                $nome = $cliente['nome_cli'];
                echo "<option value='$id'>$nome</option>";
            }
            ?>
        </select>

        <h3>Quantidade:</h3>
        <input type="number" name="quantidade" id="quantidade">


       
        <input type="submit" name="Submit" id="Submit" value="Cadastrar">
        
    </form>
    
    <?php
        include '../Controller/controller.php';

        $controller = new Controller;
        $result = $controller->addVenda();

        echo $result;


    ?>
    
</center>
<a href="index.html"><button>Voltar</button></a>

</body>
</html>
