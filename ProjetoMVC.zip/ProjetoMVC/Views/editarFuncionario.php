<!DOCTYPE html>

<html>

<head><title>Editar Funcionario</title><link rel="stylesheet" href="styles.css">
</head>

<body>


<?php
include '../Controller/controller.php';


    if(isset($_GET['id'])){
        $id = $_GET['id'];
        $tabela = "funcionarios";
        
        $controller = new Controller;
        $user = $controller->getFuncionarioById($id, $tabela);
        
        if (!$user) {
            echo 'Funcionario nao encontrado...';  
            exit;
        }

        if(isset($_POST['Subimit'])){
            $nome_fun = $_POST['nome_fun'];
            $cpf = $_POST['cpf'];
            $rg = $_POST['rg'];
            $email = $_POST['email'];

            $controller->updateFuncionario($id, $nome_fun, $cpf, $rg, $email);

        }
    }else{
        echo 'ID nao fornecido';
        exit;
    }

?>

<center>
    <h1>_________Editar Funcionario_________ </h1>
    <form action="" method="post">
        
        <h3>nome_fun:</h3>
        <input type="text" name="nome_fun" id="nome_fun" value="<?php echo $user['nome_fun']; ?>">

        <h3>CPF do funcionario:</h3>
        <input type="number" name="cpf" id="cpf" value="<?php echo $user['cpf']; ?>">

        <h3>RG do funcionario:</h3>
        <input type="number" name="rg" id="rg" value="<?php echo $user['rg']; ?>">

        <h3>E-mail:</h3>
        <input type="email"  name="email" id="email" value="<?php echo $user['email']; ?>">
       
        <input type="submit" name="Subimit" id="Subimit" value="Atualizar">
        <a href="index.html">Voltar</a>
    </form>




<body>
</html>