<?php
include '../Controller/controller.php';

$controller = new Controller;
$result = $controller->selectpelaTabela('produtos');
?>

<html>
<head>
    <title>Visualizar Produtos</title>
    <style>
        body {
            background-color: #383838;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        h2 {
            color: #ffffff;
            text-align: center;
            margin-top: 50px;
        }

        table {
            margin-top: 30px;
            border-collapse: collapse;
            width: 80%;
            margin-left: auto;
            margin-right: auto;
        }

        th {
            background-color: #442264;
            color: #ffffff;
            padding: 10px;
        }

        td {
            padding: 10px;
            text-align: center;
            border-bottom: 1px solid #ffffff;
            color: #ffffff;
        }

        a {
            text-decoration: none;
            color: #ffffff;
        }

        a:hover {
            color: #4776bd;
        }

        button {
            background-color: #442264;
            border: none;
            color: white;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin: 4px 2px;
            cursor: pointer;
            border-radius: 4px;
        }

        button:hover {
            background-color: #4776bd;
        }
    </style>
</head>

<body>
    <center>
        <h2>Visualizar Produtos</h2>
        <table align="center" border="1">
            <tr>
                <th>ID</th>
                <th>Nome</th>
                <th>Valor Unitário</th>
                <th>Fabricante</th>
                <th>Ações</th>
            </tr>

            <?php
            foreach ($result as $key => $res) {
                echo "<tr>";
                echo "<td>" . $res['id'] . "</td>";
                echo "<td>" . $res['nome_prod'] . "</td>";
                echo "<td>" . $res['valor_uni'] . "</td>";
                echo "<td>" . $res['fabricante'] . "</td>";
                echo "<td>|<button onclick=\"location.href='editarProduto.php?id=$res[id]'\">Editar</button> | <button onclick=\"location.href='deletarProduto.php?id=$res[id]'\">Deletar</button> | <button onclick=\"location.href='cadastrarProduto.php'\">Cadastrar novo produto</button></td>";
                echo "</tr>";
            }
            ?>
        </table>

        <a href="index.html"><button>Voltar</button></a>
    </center>
</body>
</html>
