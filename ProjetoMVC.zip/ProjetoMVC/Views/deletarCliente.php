<?php
include '../Controller/controller.php';
$controller = new Controller;

$id = $_GET['id'];

$tabela = 'clientes';
$result = $controller->deleteCliente($id, $tabela);

if($result){
    header("Location:../View/viewClientes.php");
}else{
   echo "Falha ao deletar";
}
?>