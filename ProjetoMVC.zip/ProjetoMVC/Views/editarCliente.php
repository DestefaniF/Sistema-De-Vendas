<!DOCTYPE html>

<html>

<head><title>Editar Cliente</title><link rel="stylesheet" href="styles.css">
</head>

<body>


<?php
include '../Controller/controller.php';


    if(isset($_GET['id'])){
        $id = $_GET['id'];
        $tabela = "clientes";
        
        $controller = new Controller;
        $user = $controller->getClienteById($id, $tabela);
        
        if (!$user) {
            echo 'cliente nao encontrado...';  
            exit;
        }

        if(isset($_POST['Subimit'])){
            $nome_cli = $_POST['nome_cli'];
            $cpf = $_POST['cpf'];
            $numero = $_POST['numero'];
            $email = $_POST['email'];

            $controller->updateCliente($id, $nome_cli, $cpf, $numero, $email);

        }
    }else{
        echo 'ID nao fornecido';
        exit;
    }

?>

<center>
    <h1>_________Editar Cliente_________ </h1>
    <form action="" method="post">
        
        <h3>nome_cli:</h3>
        <input type="text" name="nome_cli" id="nome_cli" value="<?php echo $user['nome_cli']; ?>">

        <h3>CPF do cliente:</h3>
        <input type="number" name="cpf" id="cpf" value="<?php echo $user['cpf']; ?>">

        <h3>numero do cliente:</h3>
        <input type="number" name="numero" id="numero" value="<?php echo $user['numero']; ?>">

        <h3>E-mail:</h3>
        <input type="email"  name="email" id="email" value="<?php echo $user['email']; ?>">
       
        <input type="submit" name="Subimit" id="Subimit" value="Atualizar">
        <a href="index.html">Voltar</a>
    </form>




<body>
</html>