<!DOCTYPE html>

<html>

<head><title>Editar Produto</title><link rel="stylesheet" href="styles.css">
</head>

<body>


<?php
include '../Controller/controller.php';


    if(isset($_GET['id'])){
        $id = $_GET['id'];
        $tabela = "produtos";
        
        $controller = new Controller;
        $user = $controller->getProdutoById($id, $tabela);
        
        if (!$user) {
            echo 'Funcionario nao encontrado...';  
            exit;
        }

        if(isset($_POST['Subimit'])){
            $nome_prod = $_POST['nome_prod'];
            $valor_uni = $_POST['valor_uni'];
            $fabricante = $_POST['fabricante'];


            $controller->updateProduto($id, $nome_prod, $valor_uni, $fabricante);

        }
    }else{
        echo 'ID nao fornecido';
        exit;
    }

?>

<center>
    <h1>_________Editar Funcionario_________ </h1>
    <form action="" method="post">
        
        <h3>nome_prod:</h3>
        <input type="text" name="nome_prod" id="nome_prod" value="<?php echo $user['nome_prod']; ?>">

        <h3>Valor do Produto:</h3>
        <input type="text" name="valor_uni" id="valor_uni" value="<?php echo $user['valor_uni']; ?>">

        <h3>Fabricante do Produto:</h3>
        <input type="text" name="fabricante" id="fabricante" value="<?php echo $user['fabricante']; ?>">

        
       
        <input type="submit" name="Subimit" id="Subimit" value="Atualizar">
        <a href="index.html">Voltar</a>
    </form>




<body>
</html>