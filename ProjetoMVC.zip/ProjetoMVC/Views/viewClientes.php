<?php
include '../Controller/controller.php';

$controller = new Controller;
$result = $controller->selectpelaTabela('clientes');

?>

<html>
<head>
    <title>Visualizar clientes</title>
    <style>
        body {
            background-color: #383838;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        h2 {
            color: #ffffff;
            text-align: center;
            margin-top: 50px;
        }

        table {
            margin-top: 30px;
            border-collapse: collapse;
            width: 80%;
            margin-left: auto;
            margin-right: auto;
        }

        th {
            background-color: #442264;
            color: #ffffff;
            padding: 10px;
        }

        td {
            padding: 10px;
            text-align: center;
            border-bottom: 1px solid #ffffff;
            color: #ffffff;
        }

        a {
            text-decoration: none;
            color: #ffffff;
        }

        a:hover {
            color: #4776bd;
        }

        .action-links {
            display: flex;
            justify-content: center;
            gap: 10px;
        }

        .action-links button {
            background-color: #442264;
            border: none;
            color: #ffffff;
            padding: 8px 16px;
            text-decoration: none;
            border-radius: 4px;
            transition: background-color 0.3s ease;
            cursor: pointer;
        }

        .action-links button:hover {
            background-color: #4776bd;
        }

        button {
            background-color: #442264;
            border: none;
            color: white;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin: 4px 2px;
            cursor: pointer;
            border-radius: 4px;
        }

        button:hover {
            background-color: #4776bd;
        }
    </style>
</head>

<body>
<center><h2>Visualizar Clientes</h2></center>

<table align="center" border="1">
<tr>
    <th>ID</th>
    <th>Nome</th>
    <th>CPF</th>
    <th>Número</th>
    <th>E-mail</th>
    <th>Ações</th>
</tr>

<?php
    foreach ($result as $key => $res) {
        echo "<tr>";
        echo "<td>" . $res['id'] . "</td>";
        echo "<td>" . $res['nome_cli'] . "</td>";
        echo "<td>" . $res['cpf'] . "</td>";
        echo "<td>" . $res['numero'] . "</td>";
        echo "<td>" . $res['email'] . "</td>";
        echo "<td class='action-links'><button onclick=\"location.href='editarcliente.php?id=$res[id]'\">Editar</button><button onclick=\"location.href='deletarcliente.php?id=$res[id]'\">Deletar</button><button onclick=\"location.href='cadastrarcliente.php'\">Cadastrar novo cliente</button></td>";
        echo "</tr>";
    }
?>
</table>

<center>
    <a href="index.html"><button>Voltar</button></a>
</center>
</body>
</html>
