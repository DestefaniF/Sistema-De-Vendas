<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastrar Produtos</title>
    <style>
        body {
            background-color: #383838;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        h1 {
        color: #ffffff;
        text-align: center;
        margin-top: 50px;
    }

    h3 {
        color: #ffffff;
    }

    form {
        margin-top: 30px;
        text-align: center;
    }

    input[type="text"],
    input[type="number"],
    input[type="email"],
    input[type="submit"] {
        padding: 10px;
        margin-bottom: 10px;
        width: 300px;
        border-radius: 4px;
        border: none;
    }

    input[type="submit"] {
        background-color: #442264;
        color: white;
        cursor: pointer;
    }

    input[type="submit"]:hover {
        background-color: #4776bd;
    }

    a {
        display: block;
        text-align: center;
        margin-top: 20px;
        text-decoration: none;
        color: #ffffff;
    }

    button {
        background-color: #442264;
        border: none;
        color: white;
        padding: 10px 20px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 16px;
        margin: 4px 2px;
        cursor: pointer;
        border-radius: 4px;
    }

    button:hover {
        background-color: #4776bd;
    }
</style>


</head>
<body>
    
<center>
    
    <h1>_________Cadastrar Produto_________ </h1>
    <form action="" method="post">
        
        <h3>nome:</h3>
        <input type="text" name="nome_prod" id="nome_prod">

        <h3>Valor do produto:</h3>
        <input type="text" name="valor_uni" id="valor_uni">

        <h3>Fabricante do produto:</h3>
        <input type="text" name="fabricante" id="fabricante">

        
       
        <input type="submit" name="Submit" id="Submit" value="Cadastrar">
        
    </form>
    
    <?php
        include '../Controller/controller.php';

        $controller = new Controller;
        $result = $controller->addProduto();

        echo $result;


    ?>
    
</center>
<a href="index.html"><button>Voltar</button></a>

</body>
</html>