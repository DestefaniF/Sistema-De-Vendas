<?php
include '../Controller/controller.php';
$controller = new Controller;

$id = $_GET['id'];

$tabela = 'produtos';
$result = $controller->deleteProduto($id, $tabela);

if($result){
    header("Location:../View/viewProdutos.php");
}else{
   echo "Falha ao deletar";
}
?>