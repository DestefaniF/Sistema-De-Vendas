<?php
include '../Controller/controller.php';
$controller = new Controller;

$id = $_GET['id'];

$tabela = 'funcionarios';
$result = $controller->deleteFuncionario($id, $tabela);

if($result){
    header("Location:../View/viewFuncionarios.php");
}else{
   echo "Falha ao deletar";
}
?>