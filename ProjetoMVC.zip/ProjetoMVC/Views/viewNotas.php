<?php
include '../Controller/controller.php';

$controller = new Controller;
$result = $controller->viewVendas();
?>

<html>
<head>
    <title>Visualizar notas</title>
    <style>
        body {
            background-color: #383838;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        h2 {
            color: #ffffff;
            text-align: center;
            margin-top: 50px;
        }

        table {
            margin-top: 30px;
            border-collapse: collapse;
            width: 80%;
            margin-left: auto;
            margin-right: auto;
        }

        th {
            background-color: #442264;
            color: #ffffff;
            padding: 10px;
        }

        td {
            padding: 10px;
            text-align: center;
            border-bottom: 1px solid #ffffff;
            color: #ffffff;
        }

        a {
            text-decoration: none;
            color: #ffffff;
        }

        a:hover {
            color: #4776bd;
        }

        button {
            background-color: #442264;
            border: none;
            color: white;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin: 4px 2px;
            cursor: pointer;
            border-radius: 4px;
        }

        button:hover {
            background-color: #4776bd;
        }
    </style>
</head>
<body>
    <center>
        <h2>Visualizar Vendas</h2>
        <table align="center" border="1">
            <tr>
                <th>Nome do Funcionário</th>
                <th>Nome do Cliente</th>
                <th>Nome do Produto</th>
                <th>Quantidade</th>
                <th>Valor Unitário</th>
                <th>Valor Total</th>
            </tr>

            <?php
            if ($result && count($result) > 0) {
                foreach ($result as $res) {
                    echo "<tr>";
                    echo "<td>" . $res['nome_funcionario'] . "</td>";
                    echo "<td>" . $res['nome_cliente'] . "</td>";
                    echo "<td>" . $res['nome_produto'] . "</td>";
                    echo "<td>" . $res['quantidade'] . "</td>";
                    echo "<td>" . $res['valor_uni'] . "</td>";
                    echo "<td>" . $res['valor_total'] . "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='6'>Nenhum resultado encontrado.</td></tr>";
            }
            ?>
        </table>

        <a href="index.html"><button>Voltar</button></a>
    </center>
</body>
</html>
