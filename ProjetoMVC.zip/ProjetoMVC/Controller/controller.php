<?php

include_once '../Models/crud.php';
include_once '../Models/validation.php';

class Controller{
    private $crud;
    private $validation;

    public function __construct(){
        
        $this->crud = new Crud();
        $this->validation = new Validation;
    }

    //CONTROLLER DOS FUNCIONARIOS ------------------>
    public function addFuncionario(){
        if (isset($_POST['Submit'])) {
           $nome = $this->crud->escape_string($_POST['nome_fun']);
           $cpf = $this->crud->escape_string($_POST['cpf']);
           $rg = $this->crud->escape_string($_POST['rg']);
           $email = $this->crud->escape_string($_POST['email']);

           $msg = $this->validation->check_empty($_POST, array('nome_fun', 'cpf', 'rg','email'));
           if($msg == null){
               $result = $this->crud->execute("INSERT INTO funcionarios(nome_fun, cpf, rg, email) VALUES ('$nome', '$cpf','$rg', '$email')");
               echo "Funcionario inserido com sucesso";
           }else {
            echo "insira dados validos";
            }
        } 


    }

    
   
    public function selectpelaTabela($tabela){
        $result = $this->crud->getData("SELECT * FROM $tabela");
                
        return $result;
              
        }


        public function viewFuncionario(){
            $query = "SELECT * FROM funcionarios ORDER BY id"; $result = $this->crud->getData($query); 
            return $result;
        }

        public function deleteFuncionario($id)
        {
            $query="DELETE FROM funcionarios WHERE id = $id";
            $result = $this->crud->delete($query); 
            header("Location:../Views/viewFuncionarios.php");
        }

       
        
        public function updateFuncionario($id, $nome, $cpf, $rg, $email)
       {
         $nome = $this->crud->escape_string($nome);
         $cpf = $this->crud->escape_string($cpf);
         $rg = $this->crud->escape_string($rg);
         $email = $this->crud->escape_string($email);
         
         $msg = $this->validation->check_empty($_POST, array('nome_fun', 'cpf', 'rg', 'email'));
         

         if ($msg == null) {
            $query ="UPDATE funcionarios SET nome_fun='$nome', cpf= '$cpf', rg= '$rg' ,email='$email' WHERE id= $id";
            $result = $this->crud->execute($query); 
            }
            
            if ($result) {
                echo "alterado com sucesso";
             } else {
                echo "falha";
             }
       }

       


      

    public function getFuncionarioById($id, $tabela)
    {
        $id = $this->crud->escape_string($id);
        $query = "SELECT * FROM $tabela WHERE id=$id";
        $result = $this->crud->getData($query);
        if (!empty($result)) {
        return $result[0]; 
        }else {
        return null; 
         }
      
    }
    //CONTROLLER DOS PRODUTOS ------------------>
    public function addProduto(){
        if (isset($_POST['Submit'])) {
           $nome = $this->crud->escape_string($_POST['nome_prod']);
           $valor_uni = $this->crud->escape_string($_POST['valor_uni']);
           $fabricante = $this->crud->escape_string($_POST['fabricante']);


           $msg = $this->validation->check_empty($_POST, array('nome_prod', 'valor_uni', 'fabricante'));
           if($msg == null){
               $result = $this->crud->execute("INSERT INTO produtos(nome_prod, valor_uni, fabricante) VALUES ('$nome', '$valor_uni','$fabricante')");
               echo "Produto inserido com sucesso";
           }else {
            echo "insira dados validos";
            }
        } 


    }


    public function viewProduto(){
        $query = "SELECT * FROM produtos ORDER BY id"; $result = $this->crud->getData($query); 
        return $result;
    }

    public function deleteProduto($id)
    {
        $query="DELETE FROM produtos WHERE id = $id";
        $result = $this->crud->delete($query); 
        header("Location:../Views/viewProdutos.php");
    }

    public function updateProduto($id, $nome, $valor_uni, $fabricante)
    {
      $nome = $this->crud->escape_string($nome);
      $valor_uni = $this->crud->escape_string($valor_uni);
      $fabricante = $this->crud->escape_string($fabricante);
      
      
      $msg = $this->validation->check_empty($_POST, array('nome_prod', 'valor_uni', 'fabricante'));
      

      if ($msg == null) {
         $query ="UPDATE produtos SET nome_prod='$nome', valor_uni= '$valor_uni', fabricante= '$fabricante'  WHERE id= $id";
         $result = $this->crud->execute($query); 
         }
         
         if ($result) {
             echo "alterado com sucesso";
          } else {
             echo "falha";
          }
    }

    public function getProdutoById($id, $tabela)
    {
        $id = $this->crud->escape_string($id);
        $query = "SELECT * FROM $tabela WHERE id=$id";
        $result = $this->crud->getData($query);
        if (!empty($result)) {
        return $result[0]; 
        }else {
        return null; 
         }
      
    }



    //CONTROLLER DOS CLIENTES ------------------>
    public function addCliente(){
        if (isset($_POST['Submit'])) {
           $nome = $this->crud->escape_string($_POST['nome_cli']);
           $cpf = $this->crud->escape_string($_POST['cpf']);
           $numero = $this->crud->escape_string($_POST['numero']);
           $email = $this->crud->escape_string($_POST['email']);

           $msg = $this->validation->check_empty($_POST, array('nome_cli', 'cpf', 'numero','email'));
           if($msg == null){
               $result = $this->crud->execute("INSERT INTO clientes(nome_cli, cpf, numero, email) VALUES ('$nome', '$cpf','$numero', '$email')");
               echo "cliente inserido com sucesso";
           }else {
            echo "insira dados validos";
            }
        } 


    }

    
   
   

        public function viewCliente(){
            $query = "SELECT * FROM clientes ORDER BY id"; $result = $this->crud->getData($query); 
            return $result;
        }

        public function deleteCliente($id)
        {
            $query="DELETE FROM clientes WHERE id = $id";
            $result = $this->crud->delete($query); 
            header("Location:../Views/viewclientes.php");
        }

       
        
        public function updateCliente($id, $nome, $cpf, $numero, $email)
       {
         $nome = $this->crud->escape_string($nome);
         $cpf = $this->crud->escape_string($cpf);
         $numero = $this->crud->escape_string($numero);
         $email = $this->crud->escape_string($email);
         
         $msg = $this->validation->check_empty($_POST, array('nome_cli', 'cpf', 'numero', 'email'));
         

         if ($msg == null) {
            $query ="UPDATE clientes SET nome_cli='$nome', cpf= '$cpf', numero= '$numero' ,email='$email' WHERE id= $id";
            $result = $this->crud->execute($query); 
            }
            
            if ($result) {
                echo "alterado com sucesso";
             } else {
                echo "falha";
             }
       }

       


      

    public function getClienteById($id, $tabela)
    {
        $id = $this->crud->escape_string($id);
        $query = "SELECT * FROM $tabela WHERE id=$id";
        $result = $this->crud->getData($query);
        if (!empty($result)) {
        return $result[0]; 
        }else {
        return null; 
         }
      
    }

    public function addVenda()
    {
        if (isset($_POST['Submit'])) {
            $id_funcionario = $this->crud->escape_string($_POST['id_funcionario']);
            $id_produto = $this->crud->escape_string($_POST['id_produto']);
            $id_cliente = $this->crud->escape_string($_POST['id_cliente']);
            $quantidade = $this->crud->escape_string($_POST['quantidade']);
    
            $msg = $this->validation->check_empty($_POST, array('id_funcionario', 'id_produto', 'id_cliente', 'quantidade'));
    
            if ($msg == null) {
                
                $query = "SELECT valor_uni, nome_prod FROM produtos WHERE id = '$id_produto'";
                $result = $this->crud->getData($query);
    
                if ($result && count($result) > 0) {
                    $valor_uni = $result[0]['valor_uni'];
                    $nome_prod = $result[0]['nome_prod'];
    
    
                    $valor_total = $valor_uni * $quantidade;
    

                    $result = $this->crud->getData($query);
    
                    if ($result && count($result) > 0) {
                        $nome_fun = $result[0]['nome_fun'];
    

                        $query = "SELECT nome_cli FROM clientes WHERE id = '$id_cliente'";
                        $result = $this->crud->getData($query);
    
                        if ($result && count($result) > 0) {
                            $nome_cli = $result[0]['nome_cli'];
    

                            $result = $this->crud->execute("INSERT INTO vendas (id_funcionario, id_produto, id_cliente, nome_cliente, nome_funcionario, nome_produto, quantidade, valor_total, valor_uni) VALUES ('$id_funcionario', '$id_produto','$id_cliente', '$nome_cli', '$nome_fun', '$nome_prod', '$quantidade', '$valor_total', '$valor_uni')");
    
                            if ($result) {
                                echo "Venda inserida com sucesso";
                            } else {
                                echo "Ocorreu um erro ao inserir a venda";
                            }
                        } else {
                            echo "Cliente não encontrado";
                        }
                    } else {
                        echo "Funcionário não encontrado";
                    }
                } else {
                    echo "Produto não encontrado";
                }
            } else {
                echo "Insira dados válidos";
            }
        }
    }
    
    
    public function viewVendas()
    {
        $query = "SELECT * FROM vendas ORDER BY id";
        $result = $this->crud->getData($query);
        return $result;
    }
    
   

}
?>